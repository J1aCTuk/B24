import React from 'react';

const App = () => {
  return <div>1234</div>;
};

export default App;
